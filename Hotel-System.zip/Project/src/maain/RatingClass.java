package maain;

import javax.swing.*;

public class RatingClass extends JFrame {

    public RatingClass() {
        initComponents();
    }

    private void initComponents() {
        setTitle("Rate Your Experience");
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JLabel label = new JLabel("Rate your experience (1-5):");
        JComboBox<Integer> ratingBox = new JComboBox<>(new Integer[]{1, 2, 3, 4, 5});
        JButton submitButton = new JButton("Submit");
        JButton backButton = new JButton("Back");

        submitButton.addActionListener(e -> {
            int rating = (int) ratingBox.getSelectedItem();
            JOptionPane.showMessageDialog(this, "Thank you for rating us: " + rating + " stars!");
        });

        backButton.addActionListener(e -> {
            new MainPage().setVisible(true);
            dispose();
        });

        JPanel panel = new JPanel();
        panel.add(label);
        panel.add(ratingBox);
        panel.add(submitButton);
        panel.add(backButton);

        add(panel);
        pack();
        setLocationRelativeTo(null);
    }
}

