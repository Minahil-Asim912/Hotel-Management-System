package maain;

import java.util.ArrayList;
import java.util.List;

public class RoomManager {

    private static final List<String> bookedRooms = new ArrayList<>();

    // Simulate loading rooms from a database or file
    public static void loadRooms() {
        bookedRooms.add("101");
        bookedRooms.add("102");
        bookedRooms.add("201");
    }

    // Check if a room is available
    public static boolean isRoomAvailable(String roomNo) {
        return !bookedRooms.contains(roomNo);
    }

    // Book a room
    public static void bookRoom(String roomNo) {
        if (isRoomAvailable(roomNo)) {
            bookedRooms.add(roomNo);
        }
    }

    // Cancel a booking
    public static void cancelRoom(String roomNo) {
        bookedRooms.remove(roomNo);
    }

    // Display booked rooms
    public static List<String> getBookedRooms() {
        return new ArrayList<>(bookedRooms);
    }
}
