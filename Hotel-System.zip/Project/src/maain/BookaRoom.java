package maain;

import javax.swing.*;

public class BookaRoom extends JFrame {

    private JTextField roomField;

    public BookaRoom() {
        initComponents();
    }

    private void initComponents() {
        setTitle("Book a Room");
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JLabel label = new JLabel("Enter Room Number to Book:");
        roomField = new JTextField(10);

        JButton bookButton = new JButton("Book");
        JButton backButton = new JButton("Back");

        bookButton.addActionListener(e -> bookRoom());
        backButton.addActionListener(e -> {
            new MainPage().setVisible(true);
            dispose();
        });

        JPanel panel = new JPanel();
        panel.add(label);
        panel.add(roomField);
        panel.add(bookButton);
        panel.add(backButton);

        add(panel);
        pack();
        setLocationRelativeTo(null);
    }

    private void bookRoom() {
        String roomNo = roomField.getText();
        if (RoomManager.isRoomAvailable(roomNo)) {
            RoomManager.bookRoom(roomNo);
            JOptionPane.showMessageDialog(this, "Room " + roomNo + " booked successfully!");
        } else {
            JOptionPane.showMessageDialog(this, "Room " + roomNo + " is already booked.");
        }
    }
}

