
package maain;

public class Maain {
    public static void main(String[] args) {
       
        javax.swing.SwingUtilities.invokeLater(() -> new Login().setVisible(true));
    }
}
