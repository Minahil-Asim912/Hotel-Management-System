
package maain;

import javax.swing.*;

public class Login extends JFrame {
    public static String currentPassword = "12345"; // Temporary password

    public Login() {
        initComponents();
    }

    private void initComponents() {
        setTitle("Login");
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        // UI components
        JLabel emailLabel = new JLabel("Email:");
        JTextField emailField = new JTextField(20);
        JLabel passwordLabel = new JLabel("Password:");
        JPasswordField passwordField = new JPasswordField(20);
        JButton loginButton = new JButton("Login");
        JButton signUpButton = new JButton("Sign Up");

        loginButton.addActionListener(e -> {
            String email = emailField.getText();
            String password = new String(passwordField.getPassword());

            if ("eman@gmail.com".equals(email) && currentPassword.equals(password)) {
                JOptionPane.showMessageDialog(this, "Login Successful!");
                new MainPage().setVisible(true);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Invalid email or password.");
            }
        });

        signUpButton.addActionListener(e -> {
            new SignUp().setVisible(true);
            dispose();
        });

        JPanel panel = new JPanel();
        panel.add(emailLabel);
        panel.add(emailField);
        panel.add(passwordLabel);
        panel.add(passwordField);
        panel.add(loginButton);
        panel.add(signUpButton);

        add(panel);
        pack();
        setLocationRelativeTo(null);
    }

   public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Login().setVisible(true));
    }
}