
package maain;
import javax.swing.*;

public class ChangePassword extends JFrame {
    public ChangePassword() {
        initComponents();
    }

    private void initComponents() {
        setTitle("Change Password");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        JLabel oldPasswordLabel = new JLabel("Old Password:");
        JPasswordField oldPasswordField = new JPasswordField(20);
        JLabel newPasswordLabel = new JLabel("New Password:");
        JPasswordField newPasswordField = new JPasswordField(20);
        JLabel confirmNewPasswordLabel = new JLabel("Confirm New Password:");
        JPasswordField confirmNewPasswordField = new JPasswordField(20);
        JButton changePasswordButton = new JButton("Change Password");

        changePasswordButton.addActionListener(e -> {
            String oldPassword = new String(oldPasswordField.getPassword());
            String newPassword = new String(newPasswordField.getPassword());
            String confirmNewPassword = new String(confirmNewPasswordField.getPassword());

            if (!oldPassword.equals(Login.currentPassword)) {
                JOptionPane.showMessageDialog(this, "Old password is incorrect.");
            } else if (!newPassword.equals(confirmNewPassword)) {
                JOptionPane.showMessageDialog(this, "New passwords do not match.");
            } else {
                Login.currentPassword = newPassword;
                JOptionPane.showMessageDialog(this, "Password changed successfully.");
                new MainPage().setVisible(true);
                dispose();
            }
        });

        add(oldPasswordLabel);
        add(oldPasswordField);
        add(newPasswordLabel);
        add(newPasswordField);
        add(confirmNewPasswordLabel);
        add(confirmNewPasswordField);
        add(changePasswordButton);

        pack();
        setLocationRelativeTo(null);
    }
}
