
package maain;


import javax.swing.*;

public class MainPage extends JFrame {

    public MainPage() {
        initComponents();
    }

    private void initComponents() {
        setTitle("Main Menu");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        // Create buttons
        JButton checkAvailability = new JButton("Check Availability");
        JButton bookRoom = new JButton("Book a Room");
        JButton cancelBooking = new JButton("Cancel Booking");
        JButton changePassword = new JButton("Change Password");
        JButton rateExperience = new JButton("Rate Experience");
        JButton logout = new JButton("Logout");

        // Set button actions
        checkAvailability.addActionListener(e -> {
            new CheckAvailability().setVisible(true);
            dispose(); // Close MainPage
        });

        bookRoom.addActionListener(e -> {
            new BookaRoom().setVisible(true);
            dispose();
        });

        cancelBooking.addActionListener(e -> {
            new CancelBooking().setVisible(true);
            dispose();
        });

        changePassword.addActionListener(e -> {
            new ChangePassword().setVisible(true);
            dispose();
        });

        rateExperience.addActionListener(e -> {
            new RatingClass().setVisible(true);
            dispose();
        });

        logout.addActionListener(e -> {
            new Login().setVisible(true);
            dispose();
        });

        // Add buttons to the frame
        JPanel panel = new JPanel();
        panel.add(checkAvailability);
        panel.add(bookRoom);
        panel.add(cancelBooking);
        panel.add(changePassword);
        panel.add(rateExperience);
        panel.add(logout);

        add(panel);
        pack();
        setLocationRelativeTo(null); // Center the frame
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainPage().setVisible(true));
    }
}
