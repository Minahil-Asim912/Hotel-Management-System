package maain;

import javax.swing.*;
import java.awt.*;

public class CheckAvailability extends JFrame {

    private JTextArea displayArea;

    public CheckAvailability() {
        initComponents();
    }

    private void initComponents() {
        setTitle("Check Availability");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        displayArea = new JTextArea();
        displayArea.setEditable(false);

        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> {
            new MainPage().setVisible(true);
            dispose();
        });

        add(new JScrollPane(displayArea), BorderLayout.CENTER);
        add(backButton, BorderLayout.SOUTH);

        RoomManager.loadRooms();
        displayAvailableRooms();
        pack();
        setLocationRelativeTo(null);
    }

    private void displayAvailableRooms() {
        displayArea.setText("Available Rooms:\n");
        for (int i = 101; i <= 110; i++) {
            String roomNo = String.valueOf(i);
            if (RoomManager.isRoomAvailable(roomNo)) {
                displayArea.append("Room " + roomNo + " is available.\n");
            } else {
                displayArea.append("Room " + roomNo + " is booked.\n");
            }
        }
    }
}



