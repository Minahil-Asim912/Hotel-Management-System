
package maain;

import javax.swing.*;

public class CancelBooking extends JFrame {

    private JTextField roomField;

    public CancelBooking() {
        initComponents();
    }

    private void initComponents() {
        setTitle("Cancel Booking");
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JLabel label = new JLabel("Enter Room Number to Cancel:");
        roomField = new JTextField(10);

        JButton cancelButton = new JButton("Cancel");
        JButton backButton = new JButton("Back");

        cancelButton.addActionListener(e -> cancelRoom());
        backButton.addActionListener(e -> {
            new MainPage().setVisible(true);
            dispose();
        });

        JPanel panel = new JPanel();
        panel.add(label);
        panel.add(roomField);
        panel.add(cancelButton);
        panel.add(backButton);

        add(panel);
        pack();
        setLocationRelativeTo(null);
    }

    private void cancelRoom() {
        String roomNo = roomField.getText();
        if (!RoomManager.isRoomAvailable(roomNo)) {
            RoomManager.cancelRoom(roomNo);
            JOptionPane.showMessageDialog(this, "Booking for room " + roomNo + " canceled successfully!");
        } else {
            JOptionPane.showMessageDialog(this, "Room " + roomNo + " is not booked.");
        }
    }
}
